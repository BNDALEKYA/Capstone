export interface Alert {
  alertType: string;
  message: string;
  duration?: number;
}
