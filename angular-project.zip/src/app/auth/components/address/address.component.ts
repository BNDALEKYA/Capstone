import { Component, OnInit } from '@angular/core';
import { Address } from '../../models/address';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-address',
  templateUrl: './address.component.html',
  styleUrls: ['./address.component.css'],
})
export class AddressComponent implements OnInit {
  address: Address = new Address();
  constructor(private authService: AuthService, private router: Router) {}

  addAddressSubmit() {
    this.authService.addAddress(this.address).subscribe(
      (res) => {
        console.log('success');
        this.router.navigate(['/dashboard']);
      },
      (err) => {
        console.log(JSON.stringify(err));
      }
    );
  }

  ngOnInit(): void {}
}
