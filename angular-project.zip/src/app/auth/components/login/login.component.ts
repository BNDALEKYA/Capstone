import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertService } from 'src/app/core/services/alert.service';
import { Login } from '../../models/login';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  login: Login = new Login();

  constructor(
    private authService: AuthService,
    private router: Router,
    private alertService: AlertService
  ) {}

  loginSubmit() {
    console.log(JSON.stringify(this.login));

    const newUser: any = {
      username: this.login.username,
      password: this.login.password,
    };
    // Here in subscribe we have two things success and failure part (sucess is then part and failure is catch part according to axios)
    this.authService.loginUser(newUser).subscribe(
      (res) => {
        console.log('User Logged In successfully');
        this.router.navigate(['/search']);
        this.alertService.setAlert({
          alertType: 'success',
          message: 'Login Success',
        });
        console.log(JSON.stringify(res)); //if login->success --->generates a token=>prints token
        localStorage.setItem('token', res.accessToken); //to store the token
      },
      (err) => {
        if (this.login.username == null) {
          this.alertService.setAlert({
            alertType: 'danger',
            message: 'email should not be blank',
          });
        } else {
          this.alertService.setAlert({
            alertType: 'danger',
            message: 'Login failed',
          });
        }
      }
    );
  }

  ngOnInit(): void {}
}
