import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  // If we want to use the services
  // we should use DI ( enables loose coupling)
  // just create a reference inside the constructor argument
  // will perform the DI

  constructor(private httpClient: HttpClient, private router: Router) {}

  // This registerUser should help us to do a rest call
  registerUser(data: any): Observable<any> {
    return this.httpClient.post('/api/auth/signup', data);
  }
  loginUser(data: any): Observable<any> {
    console.log('from loginUser() of authServcie');
    return this.httpClient.post('/api/auth/signin', data);
  }
  // logoutUser() {
  //   localStorage.removeItem('token');
  //   this.router.navigate(['/dashboard']);
  // }
  loadUser(): Observable<any> {
    return this.httpClient.get('/api/auth');
  }
  addAddress(data: any): Observable<any> {
    return this.httpClient.post('/api/auth/saveaddress', data);
  }
  // upload(data: any): Observable<any> {
  //   return this.httpClient.post('/api/upload', data);
  // }
}
