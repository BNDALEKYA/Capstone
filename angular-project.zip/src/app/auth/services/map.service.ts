import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class MapService {
  private authUrl =
    '/api/security/oauth/token?grant_type=client_credentials&client_id=33OkryzDZsLEmQAh7NeqqamUmqesPAMFIYe-y7WEvr3wyWWtKf7t6llyR7IKliLIaEOaIVPSRELR4HiIQVZpxXo6vNOyVcY5PX3eT99V7GF8HqK2lgVA3Q==&client_secret=lrFxI-iSEg9C2UEcHSXpMLBlKHRG6wq6i8lRpHBm9RCxbXqL42_fh0l_tcAYWM63WfSH1X-u71AzbC4ZGm5q9dDn80-_4cPp9lNZZgV_8xrmUCm4zKWGG0HZPD7g2roC';
  private mapToken: string = '';

  private addressUrl = '/api/places/geocode';

  constructor(private http: HttpClient) {
    this.getToken();
  }

  getToken() {
    this.http.post(this.authUrl, {}).subscribe((res: any) => {
      console.log(res);
      this.mapToken = res.access_token;
      console.log(this.mapToken);
    });
  }
  getAddress(address: string) {
    const tempUrl = this.addressUrl + '?itemCount=5&address=' + address;
    console.log({ tempUrl });
    return this.http.get(tempUrl, {
      headers: {
        Authorization: this.mapToken,
      },
    });
  }
  saveAddressToDatabase(address) {
    console.log({ AddressGoingToSave: address });
    return this.http.post('/api/auth/saveaddress', address);
  }
}
