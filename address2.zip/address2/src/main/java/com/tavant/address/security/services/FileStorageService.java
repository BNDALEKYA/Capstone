package com.tavant.address.security.services;

import java.io.IOException;
import java.util.List;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.tavant.address.helper.csvfieldreader;
import com.tavant.address.models.FileDB;
import com.tavant.address.repository.FileDBRepository;
@Service
public class FileStorageService {
  @Autowired
  FileDBRepository repository;

  public void save(MultipartFile file) {
    try {
      List<FileDB> filedbs = csvfieldreader.csvToTutorials(file.getInputStream());
      repository.saveAll(filedbs);
    } catch (IOException e) {
      throw new RuntimeException("fail to store csv data: " + e.getMessage());
    }
  }

  public Stream<FileDB> getAllTutorials() {
    return repository.findAll().stream();
  }
}