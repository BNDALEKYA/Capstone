package com.tavant.address.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="address2")
public class FileDB {


	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@Column(name = "housenumber")
	private String housenumber;
	@Column(name = "housename")
	private String housename;
	@Column(name = "poi")
	private String poi;
	@Column(name = "street")
	private String street;
	@Column(name = "subsublocality")
	private String subsublocality;
	@Column(name = "sublocality")
	private String sublocality;
	@Column(name = "locality")
	private String locality;
	@Column(name = "village")
	private String village;
	@Column(name = "subdistrict")
	private String subdistrict;
	@Column(name = "district")
	private String district;
	@Column(name = "city")
	private String city;
	@Column(name = "state")
	private String state;
	@Column(name = "pincode")
	private String pincode;
	@Column(name = "formattedaddress")
	private String formattedaddress;
	@Column(name = "eloc")
	private String eloc;
	@Column(name = "geocodelevel")
	private String geocodelevel;
	@Column(name = "confidencescore")
	private String confidencescore;

  

  public FileDB() {

  }

  public FileDB(int id, String housenumber, String housename, String poi, String street, String subsublocality, String sublocality, String locality, String village, String subdistrict, String district, String city, String state, String pincode, String formattedaddress, String eloc, String geocodelevel, String confidencescore ) {
	  
	  this.id= id;
	  this.housenumber= housenumber;
	  this.housename= housename;
	  this.poi=poi;
	  this.street= street;
	  this.subsublocality= subsublocality;
	  this.sublocality= sublocality;
	  this.locality= locality;
	  this.village= village;
	  this.subdistrict=subdistrict;
	  this.district= district;
	  this.city=city;
	  this.state=state;
	  this.pincode=pincode;
	  this.formattedaddress= formattedaddress;
	  this.eloc=eloc;
	  this.geocodelevel=geocodelevel;
	  this.confidencescore=confidencescore;

  }

public Integer getId() {
	return id;
}

public void setId(Integer id) {
	this.id = id;
}

public String getHousenumber() {
	return housenumber;
}

public void setHousenumber(String housenumber) {
	this.housenumber = housenumber;
}

public String getHousename() {
	return housename;
}

public void setHousename(String housename) {
	this.housename = housename;
}

public String getPoi() {
	return poi;
}

public void setPoi(String poi) {
	this.poi = poi;
}

public String getStreet() {
	return street;
}

public void setStreet(String street) {
	this.street = street;
}

public String getSubsublocality() {
	return subsublocality;
}

public void setSubsublocality(String subsublocality) {
	this.subsublocality = subsublocality;
}

public String getSublocality() {
	return sublocality;
}

public void setSublocality(String sublocality) {
	this.sublocality = sublocality;
}

public String getLocality() {
	return locality;
}

public void setLocality(String locality) {
	this.locality = locality;
}

public String getVillage() {
	return village;
}

public void setVillage(String village) {
	this.village = village;
}

public String getSubdistrict() {
	return subdistrict;
}

public void setSubdistrict(String subdistrict) {
	this.subdistrict = subdistrict;
}

public String getDistrict() {
	return district;
}

public void setDistrict(String district) {
	this.district = district;
}

public String getCity() {
	return city;
}

public void setCity(String city) {
	this.city = city;
}

public String getState() {
	return state;
}

public void setState(String state) {
	this.state = state;
}

public String getPincode() {
	return pincode;
}

public void setPincode(String pincode) {
	this.pincode = pincode;
}

public String getFormattedaddress() {
	return formattedaddress;
}

public void setFormattedaddress(String formattedaddress) {
	this.formattedaddress = formattedaddress;
}

public String getEloc() {
	return eloc;
}

public void setEloc(String eloc) {
	this.eloc = eloc;
}

public String getGeocodelevel() {
	return geocodelevel;
}

public void setGeocodelevel(String geocodelevel) {
	this.geocodelevel = geocodelevel;
}

public String getConfidencescore() {
	return confidencescore;
}

public void setConfidencescore(String confidencescore) {
	this.confidencescore = confidencescore;
}

@Override
public String toString() {
  return "Address [id=" + id + ", house number=" + housenumber + ", house name=" + housename + ", poi=" + poi + ", street=" + street + ", sub sub locality=" + subsublocality + ", sub locality=" + sublocality + ", locality=" + locality + ", village=" + village + ", sub District =" + subdistrict + ", district=" + district + ", city=" + city + ", state=" + state + ", pincode=" + pincode + ", formatted address=" + formattedaddress + ", eloc=" + eloc + ", geocode level=" + geocodelevel + ", confidence score=" + confidencescore  + "]";
}
}

