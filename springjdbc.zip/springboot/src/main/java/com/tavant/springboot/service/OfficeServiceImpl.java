package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import javax.naming.InvalidNameException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tavant.springboot.dao.EmployeeDao;
import com.tavant.springboot.dao.OfficeDao;
import com.tavant.springboot.model.Office;
@Service("officeService")
public class OfficeServiceImpl implements OfficeService {
@Autowired
	private OfficeDao officeDao;
	@Override
	public boolean addOffice(Office office) {
		// TODO Auto-generated method stub
		return this.officeDao.addOffice(office);
	}

	@Override
	public Optional<Office> updateOffice(String Code, Office office) throws InvalidNameException {
		// TODO Auto-generated method stub
		return this.officeDao.updateOffice(Code,office);
	}

	@Override
	public Optional<List<Office>> getOffices() {
		// TODO Auto-generated method stub
		return this.officeDao.getOffices();
	}

	@Override
	public Optional<Office> getOfficeByNumber(String Code) {
		// TODO Auto-generated method stub
		return this.officeDao.getOfficeByNumber(Code);
	}

	@Override
	public boolean isExists(String officeCode) {
		// TODO Auto-generated method stub
		return this.officeDao.isExists(officeCode);
	}

	@Override
	public Optional<Office> deleteOffice(String officeCode) {
		// TODO Auto-generated method stub
		return this.officeDao.deleteOffice(officeCode);
	}

}
