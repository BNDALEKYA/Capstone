package com.tavant.springboot.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.naming.InvalidNameException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tavant.springboot.model.Office;
import com.tavant.springboot.model.Products;
import com.tavant.springboot.model.Products;
import com.tavant.springboot.utils.DBUtils;
@Repository
public class ProductsDaoImpl implements ProductsDao {

	@Autowired
	DBUtils dbUtils;
	@Override
	public boolean addProducts(Products products ) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				String insertStatement = "insert into products (productCode,productName,productLine,ProductScale,productVendor,ProductDescription,quantityInStock,buyPrice,MSRP) values(?,?,?,?,?,?,?,?,?)";
				// TODO Auto-generated method stub
				Connection connection = null;
				PreparedStatement preparedStatement = null;
				connection = dbUtils.getConnection();
				try {
					preparedStatement = connection.prepareStatement(insertStatement);
					System.out.println("hello");
					preparedStatement.setString(1, products.getProductCode());
					preparedStatement.setString(2, products.getProductName());
					preparedStatement.setString(3, products.getProductLine());
					preparedStatement.setString(4, products.getProductScale());
					preparedStatement.setString(5, products.getProductVendor());
					preparedStatement.setString(6, products.getProductDescription());
					preparedStatement.setInt(7, products.getQuantityInStock());
					preparedStatement.setDouble(8, products.getBuyPrice());
					preparedStatement.setDouble(9, products.getMSRP());
					int result = preparedStatement.executeUpdate();
					if(result>0)
						return true;
					System.out.println(result);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				finally {
					dbUtils.closeConnection(connection);
				}
				return false;
	}

	@Override
	public Optional<Products> updateProducts(String pCode, Products products) throws InvalidNameException {
		// TODO Auto-generated method stub
		Connection connection = null;
        PreparedStatement preparedStatement = null;
        String query = " Update products set productCode = ? ,productName = ? ,  productLine= ? , productScale = ? ,  productVendor= ? , productDescription = ? , quantityInStock = ? ,  buyPrice=?, MSRP =? where productCode = ?";
        connection = dbUtils.getConnection();
        try {
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, products.getProductCode());
			preparedStatement.setString(2, products.getProductName());
			preparedStatement.setString(3, products.getProductLine());
			preparedStatement.setString(4, products.getProductScale());
			preparedStatement.setString(5, products.getProductVendor());
			preparedStatement.setString(6, products.getProductDescription());
			preparedStatement.setInt(7, products.getQuantityInStock());
			preparedStatement.setDouble(8, products.getBuyPrice());
			preparedStatement.setDouble(9, products.getMSRP());
			int result = preparedStatement.executeUpdate();
            System.out.println(result);
            return Optional.of(products);
           
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        finally {
            dbUtils.closeConnection(connection);
        }
       
       
        return Optional.empty();
    

	}

	@Override
	public Optional<List<Products>> getProducts() {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<Products> Products = new ArrayList<Products>();
		
		String query = "select * from products";
		// we need the connection
		connection  = dbUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(query);
			
			resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				Products products = new Products();
				products.setProductCode(resultSet.getString("productCode"));
				products.setProductName(resultSet.getString("productName"));
				products.setProductLine(resultSet.getString("productLine"));
				products.setProductScale(resultSet.getString("productScale"));
				products.setProductVendor(resultSet.getString("productVendor"));
				products.setProductDescription(resultSet.getString("productDescription"));
				products.setQuantityInStock(resultSet.getInt("quantityInStock"));
				products.setBuyPrice(resultSet.getDouble("buyPrice"));
				products.setMSRP(resultSet.getDouble("MSRP"));
				//System.out.println(products);
				// then can i add the data into the list by calling add method?
				Products.add(products);
				
			}
			return Optional.of(Products);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		return Optional.empty();
	}

	@Override
	public Optional<Products> getProductsByCode(String pCode) {
		// TODO Auto-generated method stub
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		String query = "select * from products where productCode =?";
		try {
			preparedStatement = dbUtils.getConnection().prepareStatement(query);
			preparedStatement.setString(1, (pCode));
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next()) {
				Products products = new Products();
				products.setProductCode(resultSet.getString("productCode"));
				products.setProductName(resultSet.getString("productName"));
				products.setProductLine(resultSet.getString("productLine"));
				products.setProductScale(resultSet.getString("productScale"));
				products.setProductVendor(resultSet.getString("productVendor"));
				products.setProductDescription(resultSet.getString("productDescription"));
				products.setQuantityInStock(resultSet.getInt("quantityInStock"));
				products.setBuyPrice(resultSet.getDouble("buyPrice"));
				products.setMSRP(resultSet.getDouble("MSRP"));
				System.out.println(products);
				return Optional.of(products);
			}
			else {
				return Optional.empty();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Optional.empty();
	}

	@Override
	public boolean isExists(String pCode) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Optional<Products> deleteProducts(String pCode) {
		// TODO Auto-generated method stub
		return null;
	}

}
