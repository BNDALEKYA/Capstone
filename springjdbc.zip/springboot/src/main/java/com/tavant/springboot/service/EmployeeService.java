package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import javax.naming.InvalidNameException;

import com.tavant.springboot.exception.InvalidSalaryException;
import com.tavant.springboot.model.Employee;

public interface EmployeeService {
	public boolean addEmployee(Employee emp);
	public Optional<Employee> updateEmployee(String empId , Employee employee) 
			throws InvalidSalaryException , InvalidNameException;
	public Optional<List<Employee>> getEmployees();
	//public Optional<Employee> deleteEmploye(String empid);
	public Optional<Employee> getEmployeeById(String empid);
	public boolean isExists(String empId);
	public Optional<Employee> deleteEmployee(int i);
}
