package com.tavant.springboot.dao;

import java.util.List;
import java.util.Optional;

import javax.naming.InvalidNameException;

import com.tavant.springboot.model.Office;

public interface OfficeDao {

	public boolean addOffice(Office office);
	public Optional<Office> updateOffice(String Code , Office office)throws InvalidNameException;
	public Optional<List<Office>> getOffices();
	public Optional<Office> getOfficeByNumber(String Code);
	public boolean isExists(String officeCode);
	public Optional<Office> deleteOffice(String officeCode);
}
