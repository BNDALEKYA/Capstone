package com.tavant.springboot.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.naming.InvalidNameException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tavant.springboot.exception.InvalidSalaryException;
import com.tavant.springboot.model.Employee;
import com.tavant.springboot.utils.DBUtils;
@Repository

public class EmployeeDaoImpl implements EmployeeDao {

	// do we need the DBUtils object?
	@Autowired
	DBUtils dbUtils;
//	private static EmployeeDao employeeDAO;
//
//	private EmployeeDaoImpl() {
//	}
//
//	public static EmployeeDao getInstance() {
//		if (employeeDAO == null) {
//			synchronized (EmployeeDaoImpl.class) {
//				if (employeeDAO == null) {
//					employeeDAO = new EmployeeDaoImpl();
//				}
//			}
//		}
//
//		return employeeDAO;
//	}

	@Override
	public boolean addEmployee(Employee emp) {
		String insertStatement = "insert into employees (firstName,lastName,extension,jobTitle,email,officeCode,reportsTo,employeeNumber) values(?,?,?,?,?,?,?,?)";
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		connection = dbUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(insertStatement);
			System.out.println("hello");
			preparedStatement.setString(1, emp.getFirstName());
			preparedStatement.setString(2, emp.getLastName());
			preparedStatement.setString(3, emp.getExtention());
			preparedStatement.setString(4, emp.getJobTitle());
			preparedStatement.setString(5, emp.getEmail());
			preparedStatement.setString(6, emp.getOfficeCode());
			preparedStatement.setInt(7, emp.getReportsTo());
			preparedStatement.setInt(8, emp.getEmployeeNumber());
			int result = preparedStatement.executeUpdate();
			if(result>0)
				return true;
			System.out.println(result);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		return false;
	}

	@Override
	public Optional<Employee> updateEmployee(String empId, Employee employee)
			throws InvalidSalaryException, InvalidNameException {
		Connection connection = null;
        PreparedStatement preparedStatement = null;
        String query = " Update employees set firstName = ? , lastName = ? , extension = ? , jobTitle = ? , email = ? , officeCode = ? , reportsTo = ? where employeeNumber = ?";
        connection = dbUtils.getConnection();
        try {
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, employee.getFirstName());
            preparedStatement.setString(2, employee.getLastName());
            preparedStatement.setString(3, employee.getExtention());
            preparedStatement.setString(4, employee.getJobTitle());
            preparedStatement.setString(5, employee.getEmail());
            preparedStatement.setString(6, employee.getOfficeCode());
            preparedStatement.setInt(7, employee.getReportsTo());
            preparedStatement.setInt(8, Integer.parseInt(empId));
            int result = preparedStatement.executeUpdate();
            System.out.println(result);
            return Optional.of(employee);
           
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        finally {
            dbUtils.closeConnection(connection);
        }
       
       
        return Optional.empty();
    

		// TODO Auto-generated method stub
		//here we need to compare the database details with the provided one and update the contents accordingly.
		

	}

	@Override
	public Optional<List<Employee>> getEmployees() {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<Employee> employees = new ArrayList<Employee>();
		
		String query = "select * from employees";
		// we need the connection
		connection  = dbUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(query);
			// your query is precompiled in case of preparedstatement.
			resultSet = preparedStatement.executeQuery();
			// resultSet.next() ==> it will check that whether the next record is there or not?
			// A ResultSet cursor is initially positionedbefore the first row; the first call to the method next makes the first row the current row; 
			//thesecond call makes the second row the current row, and so on. 
			while(resultSet.next()) {
				//System.out.println(resultSet.getInt("employeeNumber"));
				// here can i collect the data in terms of employee object ? 
				
				// we rcvd employee records in terms of int or string or double or float ===> form an object
				Employee employee = new Employee();
				employee.setEmployeeNumber(resultSet.getInt("employeeNumber"));
				employee.setFirstName(resultSet.getString("firstName"));
				employee.setLastName(resultSet.getString("lastName"));
				employee.setJobTitle(resultSet.getString("jobTitle"));
				employee.setOfficeCode(resultSet.getString("officeCode"));
				employee.setReportsTo(resultSet.getInt("reportsTo"));
				System.out.println(employee);
				// then can i add the data into the list by calling add method?
				employees.add(employee);
				
			}
			return Optional.of(employees);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		return Optional.empty();
		
	}

	@Override
	public Optional<Employee> deleteEmployee(int empid) {
		
			// TODO Auto-generated method stub
			Connection connection = null;
			PreparedStatement preparedStatement = null;
			Statement statement = null;
			//ResultSet resultSet = null;
			String query = " delete on  employees where"
					+ " employeeNumber =  empid  ";
	try {
				
				preparedStatement = dbUtils.getConnection().prepareStatement(query);
				preparedStatement.setInt(0,empid);
				int resultSet = preparedStatement.executeUpdate();
				if(resultSet>0) {
					return Optional.empty();
				}}catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
	return Optional.empty();
				
	}
	

	@Override
	public Optional<Employee> getEmployeeById(String empid) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		String query = "select * from employees where employeeNumber =?";
		try {
			preparedStatement = dbUtils.getConnection().prepareStatement(query);
			preparedStatement.setInt(1, Integer.parseInt(empid));
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next()) {
				Employee employee = new Employee();
				employee.setEmployeeNumber(resultSet.getInt("employeeNumber"));
				employee.setFirstName(resultSet.getString("firstName"));
				employee.setLastName(resultSet.getString("lastName"));
				employee.setJobTitle(resultSet.getString("jobTitle"));
				employee.setOfficeCode(resultSet.getString("officeCode"));
				employee.setReportsTo(resultSet.getInt("reportsTo"));
				System.out.println(employee);
				return Optional.of(employee);
			}
			else {
				return Optional.empty();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Optional.empty();
	}

	@Override
	public boolean isExists(String empId) {
		// TODO Auto-generated method stub
		return false;
	}

	
	
}
