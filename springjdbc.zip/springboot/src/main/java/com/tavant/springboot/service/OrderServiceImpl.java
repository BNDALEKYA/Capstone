package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import javax.naming.InvalidNameException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tavant.springboot.dao.OfficeDao;
import com.tavant.springboot.dao.OrderDao;
import com.tavant.springboot.model.Orders;
@Service("orderService")
public class OrderServiceImpl implements OrderService {
	@Autowired
	private OrderDao orderDao;
	@Override
	public boolean addOrder(Orders order) {
		// TODO Auto-generated method stub
		return this.orderDao.addOrder(order);
	}

	@Override
	public Optional<Orders> updateOrder(String Code, Orders order) throws InvalidNameException {
		// TODO Auto-generated method stub
		return this.orderDao.updateOrder(Code,order);
	}

	@Override
	public Optional<List<Orders>> getOrders() {
		// TODO Auto-generated method stub
		return this.orderDao.getOrders();
	}

	@Override
	public Optional<Orders> getOrderByNumber(String Code) {
		// TODO Auto-generated method stub
		return this.orderDao.getOrderByNumber(Code);
	}

	@Override
	public boolean isExists(String orderCode) {
		// TODO Auto-generated method stub
		return this.orderDao.isExists(orderCode);
	}

	@Override
	public Optional<Orders> deleteorder(String orderCode) {
		// TODO Auto-generated method stub
		return this.orderDao.deleteOrder(orderCode);
	}

}
