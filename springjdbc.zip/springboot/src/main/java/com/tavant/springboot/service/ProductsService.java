package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import javax.naming.InvalidNameException;

import com.tavant.springboot.model.Products;

public interface ProductsService {
	public boolean addProducts(Products products);
	public Optional<Products> updateProducts(String pCode , Products products)throws InvalidNameException;
	public Optional<List<Products>> getProducts();
	public Optional<Products> getProductsByCode(String pCode);
	public boolean isExists(String pCode);
	public Optional<Products> deleteProducts(String pCode);

}
