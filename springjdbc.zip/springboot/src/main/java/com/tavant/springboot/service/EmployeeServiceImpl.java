package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import javax.naming.InvalidNameException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tavant.springboot.dao.EmployeeDao;
import com.tavant.springboot.exception.InvalidSalaryException;
import com.tavant.springboot.model.Employee;
@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired	
	private EmployeeDao employeeDao;

	@Override
	public boolean addEmployee(Employee emp) {
		return this.employeeDao.addEmployee(emp);
	}

	@Override
	public Optional<Employee> updateEmployee(String empId, Employee employee) throws InvalidNameException,  InvalidSalaryException {
		return this.employeeDao.updateEmployee(empId, employee);
	}

	@Override
	public Optional<List<Employee>> getEmployees() {
		
		return this.employeeDao.getEmployees();
	}

	@Override
	public Optional<Employee> deleteEmployee(int empid) {
		return this.employeeDao.deleteEmployee(empid);
	}

	@Override
	public Optional<Employee> getEmployeeById(String empid) {
		return this.employeeDao.getEmployeeById(empid);
	}

	@Override
	public boolean isExists(String empId) {
		return this.employeeDao.isExists(empId);
	}

}
