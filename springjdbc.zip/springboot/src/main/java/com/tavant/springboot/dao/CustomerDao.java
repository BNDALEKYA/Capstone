package com.tavant.springboot.dao;

import java.util.List;
import java.util.Optional;

import javax.naming.InvalidNameException;

import com.tavant.springboot.model.Customers;
import com.tavant.springboot.model.Orders;

public interface CustomerDao {
	public boolean addCustomer(Customers cust);
	public Optional<Customers> updateCustomer(String Code , Customers cust)throws InvalidNameException;
	public Optional<List<Customers>> getCustomers();
	public Optional<Customers> getCustomerByNumber(String Code);
	public boolean isExists(String cust);
	public Optional<Customers> deleteCustomer(String cust);
	

}
