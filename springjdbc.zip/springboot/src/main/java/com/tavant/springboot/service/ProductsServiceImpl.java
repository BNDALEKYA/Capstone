package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import javax.naming.InvalidNameException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tavant.springboot.dao.ProductsDao;
import com.tavant.springboot.dao.ProductsDao;
import com.tavant.springboot.model.Products;

@Service("productsService")

public class ProductsServiceImpl implements ProductsService {

	@Autowired
	private ProductsDao productsDao;
	@Override
	public boolean addProducts(Products products) {
		// TODO Auto-generated method stub
		return this.productsDao.addProducts(products);
	}

	@Override
	public Optional<Products> updateProducts(String pCode, Products products) throws InvalidNameException {
		// TODO Auto-generated method stub
		return this.productsDao.updateProducts(pCode,products);
	}

	@Override
	public Optional<List<Products>> getProducts() {
		// TODO Auto-generated method stub
		return this.productsDao.getProducts();
	}

	@Override
	public Optional<Products> getProductsByCode(String pCode) {
		// TODO Auto-generated method stub
		return this.productsDao.getProductsByCode(pCode);
	}

	@Override
	public boolean isExists(String pCode) {
		// TODO Auto-generated method stub
		return this.productsDao.isExists(pCode);
	}

	@Override
	public Optional<Products> deleteProducts(String pCode) {
		// TODO Auto-generated method stub
		return this.productsDao.deleteProducts(pCode);
	}

}
