package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import javax.naming.InvalidNameException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tavant.springboot.dao.ProductLinesDao;
import com.tavant.springboot.dao.ProductsDao;
import com.tavant.springboot.model.ProductLines;
import com.tavant.springboot.model.Products;
@Service("productlinesService")
public class ProductLinesServiceImpl implements ProductLinesService {
	@Autowired
	private ProductLinesDao productlinesDao;
	@Override
	public boolean addProductLines(ProductLines productlines) {
		// TODO Auto-generated method stub
		return this.productlinesDao.addProductLines(productlines);
	}

	@Override
	public Optional<ProductLines> updateProductLines(String pName, ProductLines productlines)
			throws InvalidNameException {
		// TODO Auto-generated method stub
		return this.productlinesDao.updateProductLines(pName,productlines);

	}

	@Override
	public Optional<List<ProductLines>> getProductLines() {
		// TODO Auto-generated method stub
		return this.productlinesDao.getProductLines();
	}

	@Override
	public Optional<ProductLines> getProductLinesByName(String pName) {
		// TODO Auto-generated method stub
		return this.productlinesDao.getProductLinesByName(pName);	
	}

	@Override
	public boolean isExists(String pName) {
		// TODO Auto-generated method stub
		return this.productlinesDao.isExists(pName);
	}

	@Override
	public Optional<ProductLines> deleteProductLines(String pName) {
		// TODO Auto-generated method stub
		return this.productlinesDao.deleteProductLines(pName);
	}

	
}
