package com.tavant.springboot.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.naming.InvalidNameException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tavant.springboot.model.Orders;
import com.tavant.springboot.model.Orders;
import com.tavant.springboot.utils.DBUtils;
@Repository
public class OrderDaoImpl implements OrderDao {
	@Autowired
	DBUtils dbUtils;
	@Override
	public boolean addOrder(Orders order) {
		// TODO Auto-generated method stub
		String insertStatement = "insert into orders (orderNumber,orderDate,requiredDate,shippedDate,status,comments,customerNumber) values(?,?,?,?,?,?,?)";
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		connection = dbUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(insertStatement);
			System.out.println("hello");
			preparedStatement.setString(1, order.getOrderNumber());
			preparedStatement.setString(2, order.getOrderDate());
			preparedStatement.setString(3, order.getRequiredDate());
			preparedStatement.setString(4, order.getShippedDate());
			preparedStatement.setString(5, order.getStatus());
			preparedStatement.setString(6, order.getComments());
			preparedStatement.setString(7, order.getCustomerNumber());
			
			int result = preparedStatement.executeUpdate();
			if(result>0)
				return true;
			System.out.println(result);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		return false;
	}
		
	@Override
	public Optional<Orders> updateOrder(String Code, Orders order) throws InvalidNameException {
		// TODO Auto-generated method stub
		Connection connection = null;
        PreparedStatement preparedStatement = null;
        String query = " Update orders set orderNumber = ? , orderDate = ? , requiredDate = ? , shippedDate = ? , status = ? , comments = ? , CustomerNumber = ? where orderNumber = ?";
        connection = dbUtils.getConnection();
        try {
        	preparedStatement.setString(1, order.getOrderNumber());
			preparedStatement.setString(2, order.getOrderDate());
			preparedStatement.setString(3, order.getRequiredDate());
			preparedStatement.setString(4, order.getShippedDate());
			preparedStatement.setString(5, order.getStatus());
			preparedStatement.setString(6, order.getComments());
			preparedStatement.setString(7, order.getCustomerNumber());
			
            
            int result = preparedStatement.executeUpdate();
            System.out.println(result);
            return Optional.of(order);
           
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        finally {
            dbUtils.closeConnection(connection);
        }
       
       
        return Optional.empty();
   

	}
		

	@Override
	public Optional<List<Orders>> getOrders() {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<Orders> orders = new ArrayList<Orders>();
		
		String query = "select * from orders";
		// we need the connection
		connection  = dbUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(query);
			
			resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				Orders order = new Orders();
				order.setOrderNumber(resultSet.getString("orderNumber"));
				order.setOrderDate(resultSet.getString("orderDate"));
				order.setRequiredDate(resultSet.getString("requiredDate"));
				order.setShippedDate(resultSet.getString("shippedDate"));
				order.setStatus(resultSet.getString("status"));
				order.setComments(resultSet.getString("comments"));
				order.setCustomerNumber(resultSet.getString("customerNumber"));
				
				//System.out.println(order);
				// then can i add the data into the list by calling add method?
				orders.add(order);
				
			}
			return Optional.of(orders);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		return Optional.empty();
	
	}

	@Override
	public Optional<Orders> getOrderByNumber(String Code) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		String query = "select * from orders where orderNumber =?";
		try {
			preparedStatement = dbUtils.getConnection().prepareStatement(query);
			preparedStatement.setInt(1, Integer.parseInt(Code));
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next()) {
				Orders order = new Orders();
				order.setOrderNumber(resultSet.getString("orderNumber"));
				order.setOrderDate(resultSet.getString("orderDate"));
				order.setRequiredDate(resultSet.getString("requiredDate"));
				order.setShippedDate(resultSet.getString("shippedDate"));
				order.setStatus(resultSet.getString("status"));
				order.setComments(resultSet.getString("comments"));
				order.setCustomerNumber(resultSet.getString("customerNumber"));
				
				System.out.println(order);
				return Optional.of(order);
			}
			else {
				return Optional.empty();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Optional.empty();
	}


	@Override
	public boolean isExists(String orderCode) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Optional<Orders> deleteOrder(String orderCode) {
		// TODO Auto-generated method stub
		return null;
	}

}
