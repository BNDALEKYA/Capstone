export class Post {
}
