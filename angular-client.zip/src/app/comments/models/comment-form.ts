export class CommentForm {
  text: string;
}
