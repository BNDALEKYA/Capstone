import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CoreRoutingModule } from './core-routing.module';
import { NavbarComponent } from './components/layout/navbar/navbar.component';
import { LandingComponent } from './components/layout/landing/landing.component';
import { FooterComponent } from './components/layout/footer/footer.component';
import { httpInterceptorProviders } from './interceptors';

@NgModule({
  declarations: [NavbarComponent, LandingComponent, FooterComponent],
  imports: [CommonModule, CoreRoutingModule],
  providers: [httpInterceptorProviders],
  exports: [NavbarComponent, LandingComponent, FooterComponent],
})
export class CoreModule {}
