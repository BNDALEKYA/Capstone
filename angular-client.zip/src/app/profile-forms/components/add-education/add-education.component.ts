import { Component, OnInit } from '@angular/core';
import { AddEducation } from '../../models/add-education';
import { AddEducationService } from '../../services/add-education.service';

@Component({
  selector: 'app-add-education',
  templateUrl: './add-education.component.html',
  styleUrls: ['./add-education.component.css'],
})
export class AddEducationComponent implements OnInit {
  addEducation: AddEducation = new AddEducation();

  constructor(private addEducationService: AddEducationService) {}
  addEducationSubmit() {
    this.addEducationService.addEducation(this.addEducation).subscribe(
      (res) => {
        console.log('succeess');
      },
      (err) => {
        console.log(JSON.stringify(err));
      }
    );
  }
  ngOnInit(): void {}
}
