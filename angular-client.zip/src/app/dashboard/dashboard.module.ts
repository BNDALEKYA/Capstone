import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { DashboardActionComponent } from './components/dashboard-actions/dashboard-action.component';
import { httpInterceptorProviders } from '../core/interceptors';
import { CreateProfileService } from '../profile-forms/services/create-profile.service';

@NgModule({
  declarations: [DashboardComponent, DashboardActionComponent],
  imports: [CommonModule, DashboardRoutingModule],
  providers: [httpInterceptorProviders, CreateProfileService],
})
export class DashboardModule {}
