import { Component, Input, OnInit } from '@angular/core';
import { Profile } from '../models/profile';

@Component({
  selector: 'app-profile-github',
  templateUrl: './profile-github.component.html',
  styleUrls: ['./profile-github.component.css'],
})
export class ProfileGithubComponent implements OnInit {
  @Input() profile: Profile;
  constructor() {}

  ngOnInit(): void {}
}
