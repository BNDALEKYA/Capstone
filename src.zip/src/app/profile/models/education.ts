export interface Education {
  current: boolean;
  _id: string;
  school: string;
  degree: string;
  fieldofstudy: string;
  from: string;
  to?: any;
  description: string;
}
