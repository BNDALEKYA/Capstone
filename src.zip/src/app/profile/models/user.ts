export class User {
  name: string;
  _id: string;
  email: string;
  password: string;
  avatar: string;
}
