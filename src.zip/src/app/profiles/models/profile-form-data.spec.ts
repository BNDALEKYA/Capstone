import { ProfileFormData } from './profile-form-data';

describe('ProfileFormData', () => {
  it('should create an instance', () => {
    expect(new ProfileFormData()).toBeTruthy();
  });
});
