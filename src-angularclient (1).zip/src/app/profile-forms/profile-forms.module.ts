import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProfileFormsRoutingModule } from './profile-forms-routing.module';
import { AddEducationComponent } from './components/add-education/add-education.component';
import { AddExperienceComponent } from './components/add-experience/add-experience.component';
import { EditProfileComponent } from './components/edit-profile/edit-profile.component';
import { CreateProfileComponent } from './components/create-profile/create-profile.component';
import { httpInterceptorProviders } from '../core/interceptors';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CreateProfileService } from './services/create-profile.service';
import { EditProfileService } from './services/edit-profile.service';
import { AddExperienceService } from './services/add-experience.service';
import { AddEducationService } from './services/add-education.service';

@NgModule({
  declarations: [
    AddEducationComponent,
    AddExperienceComponent,
    EditProfileComponent,
    CreateProfileComponent,
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    FormsModule,
    ProfileFormsRoutingModule,
  ],
  providers: [
    httpInterceptorProviders,
    CreateProfileService,
    EditProfileService,
    AddExperienceService,
    AddEducationService,
  ],
})
export class ProfileFormsModule {}
