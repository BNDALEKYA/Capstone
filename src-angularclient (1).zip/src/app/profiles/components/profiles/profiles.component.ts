import { Component, Input, OnInit } from '@angular/core';
import { Profile } from '../../models/profile';
import { ProfilesService } from '../../services/profiles.service';

@Component({
  selector: 'app-profiles',
  templateUrl: './profiles.component.html',
  styleUrls: ['./profiles.component.css'],
})
export class ProfilesComponent implements OnInit {
  profile: Profile = new Profile();
  profiles: Profile[];
  constructor(private profilesService: ProfilesService) {}

  // @Input() profiles: Profile[] = [];
  showProfiles() {
    console.log('in showProfiles()');
    this.profilesService.loadProfiles().subscribe((res) => {
      console.log(res);
      this.profiles = res;
    });
  }
  ngOnInit(): void {
    this.showProfiles();
  }
}
