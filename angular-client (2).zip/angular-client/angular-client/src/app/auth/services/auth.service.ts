import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  //if we want to use the service
  //we should use DI
  //just create a ref inside constructor arg
  //will perform the DI
  constructor(private httpClient: HttpClient) {}

  registerUser(data: any): Observable<any> {
    return this.httpClient.post('/api/users', data);
  }
  loginUser(data: any): Observable<any> {
    console.log('from loginuser');
    return this.httpClient.post('/api/auth', data);
  }
}
