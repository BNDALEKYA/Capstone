import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CommentFormComponent } from './components/comment-form/comment-form.component';
import { CommentItemComponent } from './components/comment-item/comment-item.component';
import { PostComponent } from './components/post/post.component';

const routes: Routes = [
  {
    path: 'comment-form',
    component: CommentFormComponent,
  },
  {
    path: 'comment-item',
    component: CommentItemComponent,
  },
  {
    path: 'post',
    component: PostComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CommentsRoutingModule {}
