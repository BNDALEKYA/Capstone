import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProfilesRoutingModule } from './profiles-routing.module';
import { ProfilesComponent } from './components/profiles/profiles.component';
import { ProfilesItemComponent } from './components/profiles-item/profiles-item.component';
import { httpInterceptorProviders } from '../core/interceptors';

@NgModule({
  declarations: [ProfilesComponent, ProfilesItemComponent],
  imports: [CommonModule, ProfilesRoutingModule],
  providers: [httpInterceptorProviders],
})
export class ProfilesModule {}
