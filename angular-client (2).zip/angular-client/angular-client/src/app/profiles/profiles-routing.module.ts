import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProfilesComponent } from './components/profiles/profiles.component';
import { ProfilesItemComponent } from './components/profiles-item/profiles-item.component';

const routes: Routes = [
  {
    path: 'profiles',
    component: ProfilesComponent,
  },
  {
    path: 'profiles-item',
    component: ProfilesItemComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ProfilesRoutingModule {}
