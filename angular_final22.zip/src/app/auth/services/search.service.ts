import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class SearchService {
  BASE_URL: string = 'http://localhost:8080/api/address';

  constructor(private http: HttpClient) {}
  search(keyword: string) {
    return this.http
      .get(this.BASE_URL + 'search/' + keyword)
      .pipe(map((res: Response) => res.json()));
  }
}
