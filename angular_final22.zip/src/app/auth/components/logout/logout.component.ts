// import { Component, OnInit } from '@angular/core';
// import { ActivatedRoute, Router } from '@angular/router';

// @Component({
//   selector: 'app-logout',
//   templateUrl: './logout.component.html',
//   styleUrls: ['./logout.component.css'],
// })
// export class LogoutComponent implements OnInit {
//   constructor(private router: Router, private activeRoute: ActivatedRoute) {}

//   ngOnInit(): void {}
//   logout() {
//     localStorage.removeItem('loggedInUser');
//     this.router.navigate(['/']).then(() => {
//       window.location.reload();
//     });
//   }
// }
