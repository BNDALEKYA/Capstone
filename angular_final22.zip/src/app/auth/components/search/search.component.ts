import { Component, OnInit } from '@angular/core';
import { SearchService } from '../../services/search.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css'],
})
export class SearchComponent implements OnInit {
  keyword: string;
  filteredAddress: any[100];

  constructor(private searchService: SearchService) {}

  ngOnInit(): void {}
  search(event) {
    this.filteredAddress = [];
    this.searchService.search(this.keyword).subscribe((address) => {
      this.filteredAddress = address;
    });
  }
}
