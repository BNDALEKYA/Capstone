import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AuthRoutingModule } from './auth-routing.module';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AuthService } from './services/auth.service';
import { httpInterceptorProviders } from '../core/interceptors';
import { AddressComponent } from './components/address/address.component';
import { SearchComponent } from './components/search/search.component';
import { BrowserModule } from '@angular/platform-browser';
import { SearchService } from './services/search.service';

@NgModule({
  declarations: [
    LoginComponent,
    RegisterComponent,
    AddressComponent,
    SearchComponent,
  ],

  // All servies must be registered under the providers of specific module
  providers: [AuthService, httpInterceptorProviders, SearchService],

  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    AuthRoutingModule,
    BrowserModule,
  ],
  bootstrap: [SearchComponent],
})
export class AuthModule {}
