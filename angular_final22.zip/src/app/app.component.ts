import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'angular-client';
  // loggedInUser: string = null;

  // ngOnInit() {
  //   this.loggedInUser = localStorage.getItem('loggedInUser');
  //   console.log('dfd' + this.loggedInUser + 'x');

  //   if (this.loggedInUser == '') {
  //   }
}
