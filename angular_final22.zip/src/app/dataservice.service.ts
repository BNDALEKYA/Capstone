// import { HttpClient } from '@angular/common/http';
// import { Injectable } from '@angular/core';
// import { Observable } from 'rxjs';
// import { threadId } from 'worker_threads';

// @Injectable({
//   providedIn: 'root'
// })
// export class DataserviceService {

//   baseUrl:string="http://localhost/uat/axn";

//   constructor(private httpClient: HttpClient) { }

//   public autoComplete(search :string): Observable<Autocomplete[]>
//   {
//     return this.httpClient.get<Autocomplete[]>{
//       this.baseUrl= '/api/autocomplete.php?'+'search'+search);
//     }
// }
