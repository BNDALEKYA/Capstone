package com.tavant.project.errorresponse;

import java.io.Serializable;

public abstract class ApiSubError implements Serializable {

	
	private static final long serialVersionID=1L;
}
