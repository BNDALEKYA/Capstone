package com.tavant.address.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity(name = "Login")
@Table(name = "login")
public class Login {
	

	//Below are the columns of the table(Attributes of login) 

			@Id
			private String email;
			@NotBlank(message="Password should not be blank")
			private String password;





}
