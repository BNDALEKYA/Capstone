package com.tavant.address.exception;



public class PasswordException extends Exception {
	
	public PasswordException(String msg) {
		super(msg);
	}

	
	@Override	
	public String toString() {
	
		return super.toString()+ this.getMessage();
	}
}
