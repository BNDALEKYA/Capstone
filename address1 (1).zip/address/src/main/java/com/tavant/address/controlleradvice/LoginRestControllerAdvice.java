package com.tavant.address.controlleradvice;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import com.tavant.address.errorresponse.ErrorResponse;
import com.tavant.address.exception.PasswordException;
import com.tavant.address.exception.UserNotFoundException;

@ControllerAdvice


public class LoginRestControllerAdvice {
	
@ExceptionHandler(PasswordException.class)
	
	public final ResponseEntity<ErrorResponse> handlePasswordException(PasswordException e, WebRequest req)
	{
		List<String> details= new ArrayList<String>();
		details.add(e.getLocalizedMessage());
		
		ErrorResponse errorResponse = new ErrorResponse("INCORRECT_RESPONSE",details);
		return new ResponseEntity<>(errorResponse,HttpStatus.NOT_FOUND);
	}

@ExceptionHandler(UserNotFoundException.class)

public final ResponseEntity<ErrorResponse> handleEmployeeNotFoundException(UserNotFoundException e, WebRequest req)
{
	List<String> details= new ArrayList<String>();
	details.add(e.getLocalizedMessage());
	
	ErrorResponse errorResponse = new ErrorResponse("INCORRECT_RESPONSE",details);
	return new ResponseEntity<>(errorResponse,HttpStatus.NOT_FOUND);
}
}
