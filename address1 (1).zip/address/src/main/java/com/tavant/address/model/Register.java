package com.tavant.address.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity(name = "Register")
@Table(name = "register")
public class Register {

	//Below are the columns of the table(Attributes of an register) 

			@Id
			@GeneratedValue(strategy = GenerationType.IDENTITY)
			private Long id;
			private String email;
			@NotBlank(message="Name should not be blank")
			private String name;
			@NotBlank(message="Password should not be blank")
			private String password;
			@NotBlank(message="Password2 should not be blank")
			private String password2;



}
