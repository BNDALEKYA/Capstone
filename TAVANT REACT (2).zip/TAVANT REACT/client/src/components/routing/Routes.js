import React from "react";
import PropTypes from "prop-types";
import { Route, Switch } from "react-router-dom";
import Register3 from "../auth/Register3";
import Dashboard from "../dashboard/Dashboard";
import Alert from "../common/Alert";
import PrivateRoute from "./PrivateRoute";
import ProfileForms from "../profile-forms/ProfileForms";
import Login from "../auth/Login";
import AddExperience from "../profile-forms/AddExperience";
import AddEducation from "../profile-forms/AddEducation";

const Routes = (props) => {
  return (
    <section>
      <Alert />
      <Switch>
        <Route exact path="/register" component={Register3}></Route>
        <Route exact path="/login" component={Login}></Route>
        <PrivateRoute
          exact
          path="/dashboard"
          component={Dashboard}
        ></PrivateRoute>
        <PrivateRoute
          exact
          path="/create-profile"
          component={ProfileForms}
        ></PrivateRoute>
        <PrivateRoute
          exact
          path="/edit-profile"
          component={ProfileForms}
        ></PrivateRoute>
        <PrivateRoute
          exact
          path="/add-experience"
          component={AddExperience}
        ></PrivateRoute>
        <PrivateRoute
          exact
          path="/add-education"
          component={AddEducation}
        ></PrivateRoute>
      </Switch>
    </section>
  );
};

export default Routes;
