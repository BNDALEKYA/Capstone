import React from "react";
import PropTypes from "prop-types";

const ChildComponent3 = (props) => {
  return (
    <div>
      {props.name}
      {props.dataFor3}
      <h1>hello</h1>
    </div>
  );
};

ChildComponent3.propTypes = {};

export default ChildComponent3;
