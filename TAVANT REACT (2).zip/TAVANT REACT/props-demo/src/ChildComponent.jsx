import React from "react";
import PropTypes from "prop-types";
import ChildComponent2 from "./ChildComponent2";

const ChildComponent = ({ name, name2, dataFor3 }) => {
  return (
    <div>
      <h1>hello from {name}</h1>
      <h1>hello from {name2}</h1>
      <ChildComponent2 name={name} dataFor3={dataFor3}></ChildComponent2>
    </div>
  );
};

ChildComponent.propTypes = {};

export default ChildComponent;
