import React from "react";
import PropTypes from "prop-types";
import ChildComponent3 from "./ChildComponent3";

const ChildComponent2 = (props) => {
  return (
    <div>
      {props.name}
      <h1>Hello from child2</h1>
      <ChildComponent3
        name={props.name}
        dataFor3={props.dataFor3}
      ></ChildComponent3>
    </div>
  );
};

ChildComponent2.propTypes = {};

export default ChildComponent2;
