async function f() {
  console.log("hello frm function");
  let promise = new Promise((resolve, reject) => {
    setTimeout(() => {
      console.log("hello from set timeout");
      resolve("donee");
    }, 2000);
  });
  let result = await promise;
  console.log("after the promise");
  return promise;
}

f();
//   .then((data) => console.log(data))
//   .catch((data) => console.log("data from catch" + data));
