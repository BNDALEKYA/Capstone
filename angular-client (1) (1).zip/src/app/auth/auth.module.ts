import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AuthRoutingModule } from './auth-routing.module';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AuthService } from './services/auth.service';
import { httpInterceptorProviders } from '../core/interceptors';

@NgModule({
  declarations: [LoginComponent, RegisterComponent],
  // all the services (user defined) must be registered under the providers of the specific module.
  providers: [AuthService, httpInterceptorProviders],

  imports: [CommonModule, FormsModule, HttpClientModule, AuthRoutingModule],
})
export class AuthModule {}
