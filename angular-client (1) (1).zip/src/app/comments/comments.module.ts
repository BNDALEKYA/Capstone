import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CommentsRoutingModule } from './comments-routing.module';
import { CommentFormComponent } from './components/comment-form/comment-form.component';
import { CommentItemComponent } from './components/comment-item/comment-item.component';
import { PostComponent } from './components/post/post.component';
import { httpInterceptorProviders } from '../core/interceptors';

@NgModule({
  declarations: [CommentFormComponent, CommentItemComponent, PostComponent],
  imports: [CommonModule, CommentsRoutingModule],
  providers: [httpInterceptorProviders],
})
export class CommentsModule {}
