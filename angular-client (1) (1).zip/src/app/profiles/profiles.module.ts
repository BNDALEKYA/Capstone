import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProfilesRoutingModule } from './profiles-routing.module';
import { ProfilesComponent } from './components/profiles/profiles.component';
import { ProfileItemComponent } from './components/profile-item/profile-item.component';
import { httpInterceptorProviders } from '../core/interceptors';

@NgModule({
  declarations: [ProfilesComponent, ProfileItemComponent],
  imports: [CommonModule, ProfilesRoutingModule],
  providers: [httpInterceptorProviders],
})
export class ProfilesModule {}
