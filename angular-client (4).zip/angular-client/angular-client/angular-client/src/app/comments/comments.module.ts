import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CommentsRoutingModule } from './comments-routing.module';
import { PostComponent } from './components/post/post.component';
import { CommentFormComponent } from './components/comment-form/comment-form.component';
import { CommentItemComponent } from './components/comment-item/comment-item.component';


@NgModule({
  declarations: [PostComponent, CommentFormComponent, CommentItemComponent],
  imports: [
    CommonModule,
    CommentsRoutingModule
  ]
})
export class CommentsModule { }
