import { Component, OnInit } from '@angular/core';
import { Login } from '../../models/login';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  login: Login = new Login();
  constructor(private authService: AuthService) {}

  loginSubmit() {
    console.log(JSON.stringify(this.login));

    const newUser: any = {
      email: this.login.email,
      password: this.login.password,
    };
    this.authService.loginUser(newUser).subscribe(
      (res) => {
        console.log('login successfully');
      },
      (err) => {}
    );
  }
  ngOnInit(): void {}
}
