export class AddExperience {
  company: string;
  title: string;
  location: string;
  from: Date;
  to: Date;
  current: Boolean;
  description: string;
}
