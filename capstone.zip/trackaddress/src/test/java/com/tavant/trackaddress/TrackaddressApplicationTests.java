package com.tavant.trackaddress;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrackaddressApplicationTests {

	@Test
	void contextLoads() {
	}

}
