package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import com.tavant.springboot.exception.InvalidNameException;
import com.tavant.springboot.model.Employee;
import com.tavant.springboot.model.Office;

public interface OfficeService {
	public boolean addOffice(Office office);
	public Optional<Office> updateOffice(String Code , Office office)throws InvalidNameException;
	public Optional<List<Office>> getOffices();
	public Optional<Office> getOfficeByNumber(String Code);
	public boolean isExists(String officeCode);
	public Optional<Office> deleteOffice(String officeCode);
}
