package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import javax.naming.InvalidNameException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tavant.springboot.dao.OfficeDao;
import com.tavant.springboot.dao.PaymentDao;
import com.tavant.springboot.model.Customers;
import com.tavant.springboot.model.Office;
import com.tavant.springboot.model.Payments;

@Service("paymentsService")
public class PaymentsServiceImpl implements PaymentsService {
	@Autowired
	private PaymentDao paymentsDao;

	@Override
	public boolean addPayments(Payments payments) {
		// TODO Auto-generated method stub
		Payments pmt = paymentsDao.save(payments);
		return pmt !=null;
	}

	@Override
	public Optional<Payments> updatePayments(Integer Code, Payments payments) throws InvalidNameException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<List<Payments>> getPayments() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Payments> getPaymentsByNumber(String Code) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isExists(Integer customerNumber) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Optional<Payments> deletePayments(Integer customerNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	

}
