//package com.tavant.springboot.dao;
//
//import java.util.List;
//import java.util.Optional;
//
//import javax.naming.InvalidNameException;
//
//import com.tavant.springboot.model.OrderDetails;
//
//public interface OrderDetailsDao {
//	
//	public boolean addOrderDetails(OrderDetails orderDetails);
//	public Optional<OrderDetails> updateOrderDetails(String Code , OrderDetails OrderDetails)throws InvalidNameException;
//	public Optional<List<OrderDetails>> getOrderDetails();
//	public Optional<OrderDetails> getOrderDetailsByNumber(String Code);
//	public boolean isExists(String OrderDetailsCode);
//	public Optional<OrderDetails> deleteOrderDetails(String OrderDetailsCode);
//}
//
