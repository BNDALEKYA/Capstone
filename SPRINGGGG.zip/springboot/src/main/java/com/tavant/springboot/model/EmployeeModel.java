package com.tavant.springboot.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data

@NoArgsConstructor
@Entity
public class EmployeeModel {
	
	private @Id
	@GeneratedValue(strategy = GenerationType.AUTO)

	Long id;
	public EmployeeModel(String name, String dept, int salary) {
		super();
		this.name = name;
		this.dept = dept;
		this.salary = salary;
	}
	private String name;
	private String dept;
	private int salary;

}
