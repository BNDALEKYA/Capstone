package com.tavant.springboot.service;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import javax.naming.InvalidNameException;

import org.springframework.data.jpa.repository.Query;

import com.tavant.springboot.exception.InvalidSalaryException;
import com.tavant.springboot.model.Employee;
import com.tavant.springboot.model.ICountData;

public interface EmployeeService {
	public boolean addEmployee(Employee emp);
	public Optional<Employee> updateEmployee(String empId , Employee employee);
//			throws InvalidSalaryException , InvalidNameException;
	public Optional<List<Employee>> getEmployees();
	//public Optional<Employee> deleteEmploye(String empid);
	public Optional<Employee> getEmployeeById(int empid);
	public boolean isExists(int empId);
	public Optional<Employee> deleteEmployee(int i);
	
   public Employee findTopByOderByJobTitleDesc();
   public Employee findTopByOrderByJobTitleAsc();
	
	public Optional<List<Employee>> findTop3ByOrderByJobTitleDesc();
	public Optional<List<Employee>> findTop3ByOrderByJobTitleAsc();
   
   public Optional<List<Employee>> findByOfficeCode(String officeCode);
   public Optional<List<Employee>> findFirst2ByOfficeCode(String officeCode);
   
   public Optional<List<Employee>> findByFirstNameLike(String firstName);

   public long countByOfficeCode();
   public long countByOfficeCode(String officeCode);
//public Optional<List<Object[]>> getOfficeCount(); 

public List<ICountData> getOfficeCount();

public List<HashMap<String,Object>> getEmployeeMap();


}
