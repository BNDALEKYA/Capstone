//package com.tavant.springboot.dao;
//
//import java.util.List;
//import java.util.Optional;
//
//import javax.naming.InvalidNameException;
//
//import com.tavant.springboot.model.Orders;
//
//public interface OrderDao {
//	
//	public boolean addOrder(Orders order);
//	public Optional<Orders> updateOrder(String Code , Orders order)throws InvalidNameException;
//	public Optional<List<Orders>> getOrders();
//	public Optional<Orders> getOrderByNumber(String Code);
//	public boolean isExists(String orderCode);
//	public Optional<Orders> deleteOrder(String orderCode);
//}
//
