package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import javax.naming.InvalidNameException;

import com.tavant.springboot.model.Payments;

public interface PaymentsService {
	public boolean addPayments(Payments payments);
	public Optional<Payments> updatePayments(Integer Code , Payments payments)throws InvalidNameException;
	public Optional<List<Payments>> getPayments();
	public Optional<Payments> getPaymentsByNumber(String Code);
	public boolean isExists(Integer customerNumber);
	public Optional<Payments> deletePayments(Integer customerNumber);

}
