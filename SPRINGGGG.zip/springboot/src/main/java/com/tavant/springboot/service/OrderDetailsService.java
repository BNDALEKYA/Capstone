//package com.tavant.springboot.service;
//
//import java.util.List;
//import java.util.Optional;
//
//import javax.naming.InvalidNameException;
//
//import com.tavant.springboot.model.OrderDetails;
//import com.tavant.springboot.model.OrderDetails;
//
//public interface OrderDetailsService {
//	public boolean addOrderDetail(OrderDetails OrderDetail);
//		
//	public Optional<OrderDetails> updateOrderDetail(String Code , OrderDetails OrderDetail)throws InvalidNameException;
//	public Optional<List<OrderDetails>> getOrderDetails();
//	public Optional<OrderDetails> getOrderDetailByNumber(String Code);
//	public boolean isExists(String OrderDetailCode);
//	public Optional<OrderDetails> deleteOrderDetail(String OrderDetailCode);
//
//}
