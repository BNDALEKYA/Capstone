//package com.tavant.springboot.service;
//
//import java.util.List;
//import java.util.Optional;
//
//import javax.naming.InvalidNameException;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.tavant.springboot.dao.OrderDetailsDao;
//import com.tavant.springboot.model.OrderDetails;
//@Service("orderDetailsService")
//public class OrderDetailsServiceImpl implements OrderDetailsService {
//@Autowired
//private OrderDetailsDao orderDetailsDao;
//	@Override
//	public boolean addOrderDetail(OrderDetails OrderDetail) {
//		// TODO Auto-generated method stub
//		return this.orderDetailsDao.addOrderDetails(OrderDetail);
//	}
//
//	@Override
//	public Optional<OrderDetails> updateOrderDetail(String Code, OrderDetails OrderDetail) throws InvalidNameException {
//		// TODO Auto-generated method stub
//		return this.orderDetailsDao.updateOrderDetails(Code,OrderDetail);
//	}
//
//	@Override
//	public Optional<List<OrderDetails>> getOrderDetails() {
//		// TODO Auto-generated method stub
//		return this.orderDetailsDao.getOrderDetails();
//	}
//
//	@Override
//	public Optional<OrderDetails> getOrderDetailByNumber(String Code) {
//		// TODO Auto-generated method stub
//		return this.orderDetailsDao.getOrderDetailsByNumber(Code);
//	}
//
//	@Override
//	public boolean isExists(String OrderDetailCode) {
//		// TODO Auto-generated method stub
//		return this.orderDetailsDao.isExists(OrderDetailCode);
//	}
//
//	@Override
//	public Optional<OrderDetails> deleteOrderDetail(String OrderDetailCode) {
//		// TODO Auto-generated method stub
//		return this.orderDetailsDao.deleteOrderDetails(OrderDetailCode);
//	}
//
//}
