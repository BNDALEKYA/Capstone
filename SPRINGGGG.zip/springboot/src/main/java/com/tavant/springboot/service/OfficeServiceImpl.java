package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.tavant.springboot.dao.EmployeeDao;
import com.tavant.springboot.dao.OfficeDao;
import com.tavant.springboot.exception.InvalidNameException;
import com.tavant.springboot.model.Office;


@Service("officeService")
public class OfficeServiceImpl implements OfficeService {
@Autowired
OfficeDao officeDao;
	@Override
	public boolean addOffice(Office off) {
		// TODO Auto-generated method stub
		Office office = officeDao.save(off);
		return office!=null;
	}

	@Override
	public Optional<Office> updateOffice(String Code, Office office) throws InvalidNameException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<List<Office>> getOffices() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Office> getOfficeByNumber(String Code) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isExists(String officeCode) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Optional<Office> deleteOffice(String officeCode) {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
