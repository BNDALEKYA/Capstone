package com.tavant.springboot.model;

import java.util.HashMap;

import lombok.AllArgsConstructor;
import lombok.Data;


//public class ICountData {
//	
//	private String code;
//	public long CodeCount;
//
//}
public interface ICountData {
//	HashMap<String, Long> hm = new HashMap<String, Long>();
	String getCode();
	Long getCodeCount();
}