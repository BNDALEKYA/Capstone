package com.tavant.springboot.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "payments")
public class Payments{
	@ManyToOne
	@JoinColumn(name = "customerNumber")
	private Customers customerNumber;
	private String checkNumber;
	private String paymentDate;
	private Double amount;
	@Id
	private Integer paymentId;
	

}