package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import javax.naming.InvalidNameException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tavant.springboot.dao.AccountDao;
import com.tavant.springboot.model.Account;
@Service
public class AccountServiceImpl implements AccountService {
@Autowired
private AccountDao accountDao;
	@Override
	public boolean addAccount(Account acc) {
		// TODO Auto-generated method stub
		Account account = accountDao.save(acc);
		return account!=null;
	}

	@Override
	public Optional<Account> updateAccount(String Code, Account acc) throws InvalidNameException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<List<Account>> getAccounts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Account> getAccountByNumber(String Code) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isExists(String AccountCode) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Optional<Account> deleteAccount(String AccountCode) {
		// TODO Auto-generated method stub
		return null;
	}

}
