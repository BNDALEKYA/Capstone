//package com.tavant.springboot.model;
//import javax.persistence.Entity;
//import javax.persistence.Id;
//import javax.persistence.JoinColumn;
//import javax.persistence.ManyToOne;
//import javax.persistence.Table;
//
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//@Data
//@NoArgsConstructor
//@AllArgsConstructor
//@Entity
//@Table(name = "orderDetails")
//public class OrderDetails {
//	@Id
//	@ManyToOne
//	@JoinColumn(name = "orderNumber")
//	private String orderNumber;
//	private String productCode;
//	private String quantityOrdered;
//	private String priceEach;
//	private String orderLineNumber;
//	public static boolean addOrderDetail(OrderDetails orders) {
//		// TODO Auto-generated method stub
//		return false;
//	}
//	
//	
//}
