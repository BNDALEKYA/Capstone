package com.tavant.springboot.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@IdClass(AccountId.class)
public class Account {

	@Id
	private String accountNumber;
	@Id
	private String accountType;
	private String firstname;
	private String lastname;
	private Double balance;
}
