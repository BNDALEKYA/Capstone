package com.tavant.springboot.utils;

public interface PhysicalNamingStrategyImpl {

}
