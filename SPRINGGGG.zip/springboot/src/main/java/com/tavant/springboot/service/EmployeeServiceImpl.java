package com.tavant.springboot.service;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import javax.naming.InvalidNameException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tavant.springboot.dao.EmployeeDao;
import com.tavant.springboot.exception.InvalidSalaryException;
import com.tavant.springboot.model.Employee;
import com.tavant.springboot.model.ICountData;
@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeDao employeeDao;
	@Override
	public boolean addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		Employee employee=employeeDao.save(emp);
		return employee!=null;
	}

	@Override
	public Optional<Employee> updateEmployee(String empId, Employee employee)
			 {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<List<Employee>> getEmployees() {
		// TODO Auto-generated method stub
		return Optional.ofNullable(employeeDao.findAll());
	}

	@Override
	public Optional<Employee> getEmployeeById(int empid) {
		// TODO Auto-generated method stub
		return employeeDao.findById(empid);
	}


	@Override
	public boolean isExists(int empid) {
		// TODO Auto-generated method stub
		return employeeDao.existsById(empid);
	}

	@Override
	public Optional<Employee> deleteEmployee(int i) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee findTopByOderByJobTitleDesc() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee findTopByOrderByJobTitleAsc() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<List<Employee>> findTop3ByOrderByJobTitleDesc() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<List<Employee>> findTop3ByOrderByJobTitleAsc() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<List<Employee>> findByOfficeCode(String officeCode) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<List<Employee>> findFirst2ByOfficeCode(String officeCode) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<List<Employee>> findByFirstNameLike(String firstName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long countByOfficeCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public long countByOfficeCode(String officeCode) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<ICountData> getOfficeCount() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<HashMap<String, Object>> getEmployeeMap() {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
//	public Employee findTopByOderByJobTitleDesc() {
//		// TODO Auto-generated method stub
//		return employeeDao.findTopByOrderByJobTitleDesc();
//	}
//
//
//
//	@Override
//	public Optional<List<Employee>> findByOfficeCode(String officeCode) {
//		// TODO Auto-generated method stub
//		return employeeDao.findByOfficeCode(officeCode);
//	}
//
//	@Override
//	public Employee findTopByOrderByJobTitleAsc() {
//		// TODO Auto-generated method stub
//		return employeeDao.findTopByOrderByJobTitleAsc();
//	}
//
//	@Override
//	public Optional<List<Employee>> findTop3ByOrderByJobTitleDesc() {
//		// TODO Auto-generated method stub
//		return employeeDao.findTop3ByOrderByJobTitleDesc();
//	}
//
//	@Override
//	public Optional<List<Employee>> findTop3ByOrderByJobTitleAsc() {
//		// TODO Auto-generated method stub
//		return employeeDao.findTop3ByOrderByJobTitleAsc();
//	}
//
//	@Override
//	public Optional<List<Employee>> findFirst2ByOfficeCode(String officeCode) {
//		// TODO Auto-generated method stub
//		return employeeDao.findFirst2ByOfficeCode(officeCode);
//	}
//
//	@Override
//	public Optional<List<Employee>> findByFirstNameLike(String firstName) {
//		// TODO Auto-generated method stub
//		return employeeDao.findByFirstNameLike(firstName);
//	}
//
//	@Override
//	public long countByOfficeCode(String officeCode) {
//		// TODO Auto-generated method stub
//		return employeeDao.countByOfficeCode(officeCode);
//	}
//
//	@Override
//	public long countByOfficeCode() {
//		// TODO Auto-generated method stub
//		return  employeeDao.countByOfficeCode();
//	}
//
//	@Override
//	public List<ICountData> getOfficeCount() {
//		// TODO Auto-generated method stub
//		return employeeDao.getOfficeCount();
//	}
//
//	@Override
//	public List<HashMap<String, Object>> getEmployeeMap() {
//		// TODO Auto-generated method stub
//		return employeeDao.getEmployeeMap();
//	}
//
////	@Override
////	public Optional<List<Object[]>> getOfficeCount() {
////		// TODO Auto-generated method stub
////		return employeeDao.getOfficeCount();
//	//
//		
		
	}
	

