package com.tavant.springboot.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
public class Employee implements Comparable<Employee> {
	
	@Id
	
	private Integer employeeNumber;
	private String firstName;
	
	private String lastName;
	private String extention;
	
	@Column(length =40, nullable = false) @Size(max=40)
	private String email;
	@ManyToOne
	
	@JoinColumn(name = "officeCode")
	private Office officeCode;
	private int reportsTo;
	
	@Column(length =20) @Size(max=25)
	private String jobTitle;
	
	@Override
	public int compareTo(Employee o) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
