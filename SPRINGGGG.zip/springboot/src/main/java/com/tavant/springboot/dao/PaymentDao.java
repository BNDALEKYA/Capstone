package com.tavant.springboot.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tavant.springboot.model.Customers;
import com.tavant.springboot.model.Payments;
@Repository

public interface PaymentDao extends JpaRepository<Payments,Customers>{
	

}
