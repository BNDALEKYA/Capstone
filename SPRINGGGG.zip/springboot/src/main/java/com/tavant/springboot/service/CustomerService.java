package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import javax.naming.InvalidNameException;

import com.tavant.springboot.model.Customers;

public interface CustomerService {
	
	public boolean addCustomer(Customers cust);
	
	public Optional<Customers> updateCustomer(String Code , Customers cust)throws InvalidNameException;
	public Optional<List<Customers>> getCustomers();
	public Optional<Customers> getCustomerByNumber(String Code);
	public boolean isExists(String customerCode);
	public Optional<Customers> deleteCustomer(String customerCode);

}
