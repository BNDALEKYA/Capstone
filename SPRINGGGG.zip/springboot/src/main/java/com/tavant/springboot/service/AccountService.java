package com.tavant.springboot.service;

import java.util.List;
import java.util.Optional;

import javax.naming.InvalidNameException;

import com.tavant.springboot.model.Account;

public interface AccountService {
	
public boolean addAccount(Account acc);
	
	public Optional<Account> updateAccount(String Code , Account acc)throws InvalidNameException;
	public Optional<List<Account>> getAccounts();
	public Optional<Account> getAccountByNumber(String Code);
	public boolean isExists(String AccountCode);
	public Optional<Account> deleteAccount(String AccountCode);


}
