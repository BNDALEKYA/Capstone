import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpHeaders,
} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class HeaderInterceptor implements HttpInterceptor {
  constructor() {}

  intercept(
    request: HttpRequest<unknown>,
    next: HttpHandler
  ): Observable<HttpEvent<unknown>> {
    // we can clone the request and we will send cloned one for backend interaction.
    console.log('from interceptor');

    console.log(localStorage.getItem('token'));
    if (localStorage.getItem('token') == null) {
      return next.handle(request);
    }
    request = request.clone({
      setHeaders: {
        'x-auth-token': localStorage.getItem('token'),
      },
    });

    console.log('ending interceptor');
    console.log(JSON.stringify(request));
    return next.handle(request);
  }
}
