import axios from "axios";
import classnames from "classnames";
import { useHistory } from "react-router-dom";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { register } from "../../redux/actions/auth";
import { setAlert } from "../../redux/actions/alert";
import React, { Fragment, useState } from "react";

import { Link, Redirect } from "react-router-dom";

const Employee = ({ employee, setAlert, isAuthenticated }) => {
  const [formData, setformData] = useState({
    EmpId: "",
    FirstName: "",
    LastName: "",
    email: "",
    phoneNumber: "",
    jobTitle: "",
    salary: "",
  }); //state for formdat

  //const [errors, setErrors] = useState({});

  //let history = useHistory();

  const {
    EmpId,
    FirstName,
    LastName,
    email,
    phoneNumber,
    jobTitle,
    salary,
  } = formData;
  const onChange = (e) => {
    setformData({ ...formData, [e.target.name]: e.target.value });
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    //console.log("form submitted");
    // if password and confirm password are not matched
    // then
    // do we need to raise the alert?
    // if (password !== password2) {
    //   console.log("password donot match");
    //   setAlert("password do not match", "danger");
    //   // history.push("/alert");
    // } else {
    //   register({ name, email, password, password2 });
    // }
  };
  if (isAuthenticated) {
    return <Redirect to="/dashboard"></Redirect>;
  }
  return (
    <Fragment>
      <h1 className="large text-primary">Employee Profile </h1>
      <p className="lead">
        <i className="fas fa-user" />
        Add Employee details
      </p>
      <form className="form" onSubmit={onSubmit}>
        <div className="form-group">
          <input
            type="text"
            placeholder="Empoyee Id"
            name="EmpId"
            value={EmpId}
            onChange={onChange}
          />
        </div>
        <div className="form-group">
          <input
            type="text"
            placeholder="First Name"
            name="FirstName"
            value={FirstName}
            onChange={onChange}
          />
        </div>
        <div className="form-group">
          <input
            type="text"
            placeholder="Last Name"
            name="LastName"
            value={LastName}
            onChange={onChange}
          />
        </div>
        <div className="form-group">
          <input
            type="email"
            placeholder="Email Address"
            name="email"
            value={email}
            onChange={onChange}
          />
        </div>

        <div className="form-group">
          <input
            type="text"
            placeholder="Salary"
            name="salary"
            value={salary}
            onChange={onChange}
          />
        </div>
        <div className="form-group">
          <input
            type="text"
            placeholder="Job Title"
            name="jobTitle"
            value={jobTitle}
            onChange={onChange}
          />
        </div>
        <div className="form-group">
          <input
            type="text"
            placeholder="Phone Number"
            name="phoneNumber"
            value={phoneNumber}
            onChange={onChange}
          />
        </div>
        <input
          type="submit"
          className="btn btn-primary"
          value="Add Employee Details"
        />
      </form>
      {/* <p className="my-1">
        Already have an account? <Link to="/login">Sign In</Link>
      </p> */}
    </Fragment>
  );
};

Employee.propTypes = {
  employee: PropTypes.func.isRequired,
  setAlert: PropTypes.func.isRequired,
  isAuthenticated: PropTypes.bool,
};

const mapStateToProps = (state) => ({
  isAuthenticated: state.auth.isAuthenticated,
}); //to redux which state part we want to access

const mapDispatchToProps = { register, setAlert }; // actions that u need it registe action.

export default connect(mapStateToProps, mapDispatchToProps)(Employee);
