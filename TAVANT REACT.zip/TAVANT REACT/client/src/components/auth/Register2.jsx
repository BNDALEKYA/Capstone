//hooks
// class based components : react
// will it extend to a component class
//then all features of component class and lige cycle methods will be associated with the ur class?
//if processing is expected then we should use class based component till react version 16.8
//it is bit bulky

// a function based components
//it is used only for presention work(no processing )(till 16.8)
//but from 16.9 onwards we can use a functional based component will be used for any kind of processing
// of ur application data.

//hooks allow u to use local state and other react features wothout writing a class
//then usage perspective functionalbased components become light weight
//compared with class based components

import React, { useState } from "react";
import axios from "axios";
import classnames from "classnames";
import { useHistory } from "react-router-dom";

const Register2 = (props) => {
  const [formData, setformData] = useState({
    name: "",
    email: "",
    password: "",
    password2: "",
  });

  const [errors, setErrors] = useState({});
  let history = useHistory();

  const { name, email, password, password2 } = formData;
  const onChange = (e) => {
    setformData({ ...formData, [e.target.name]: e.target.value });
  };
  const onSubmit = async (e) => {
    e.preventDefault();
    console.log("form submitted");

    if (password !== password2) {
      //alert("password mismatch");
      //console.log("alert");
      history.push("/alert");
    }

    const newUser = formData;

    axios
      .post("/api/users/register", newUser)
      .then((res) => {
        console.log(JSON.stringify(res));

        history.push("/login");
        //this.props.history.push("/login");
      })
      .catch((err) => {
        setErrors(err.response.data);
        //this.setState({ errors: err.response.data });
        console.log(JSON.stringify(err.response.data));
      });
  };
  return (
    <div className="register">
      <div className="container">
        <div className="row">
          <div className="col-md-8 m-auto">
            <h1 className="display-4 text-center">Sign Up</h1>
            <p className="lead text-center">Create your DevConnector account</p>
            <form onSubmit={onSubmit}>
              <div className="form-group">
                <input
                  type="text"
                  className={classnames("form-control form-control-lg", {
                    "is-invalid": errors.name,
                  })}
                  placeholder="Name"
                  name="name"
                  value={name}
                  onChange={onChange}
                  required
                />
                {errors.name && (
                  <div className="d-block invalid-feedback">{errors.name}</div>
                )}
              </div>
              <div className="form-group">
                <input
                  type="email"
                  className={classnames("form-control form-control-lg", {
                    "is-invalid": errors.email,
                  })}
                  placeholder="Email Address"
                  name="email"
                  value={email}
                  onChange={onChange}
                />
                {errors.email && (
                  <div className="d-block invalid-feedback">{errors.email}</div>
                )}
                <small className="form-text text-muted">
                  This site uses Gravatar so if you want a profile image, use a
                  Gravatar email
                </small>
              </div>
              <div className="form-group">
                <input
                  type="password"
                  className={classnames("form-control form-control-lg", {
                    "is-invalid": errors.password,
                  })}
                  placeholder="Password"
                  name="password"
                  value={password}
                  onChange={onChange}
                />
                {errors.password && (
                  <div className="d-block invalid-feedback">
                    {errors.password}
                  </div>
                )}
              </div>
              <div className="form-group">
                <input
                  type="password"
                  className={classnames("form-control form-control-lg", {
                    "is-invalid": errors.password2,
                  })}
                  placeholder="Confirm Password"
                  name="password2"
                  value={password2}
                  onChange={onChange}
                />
                {errors.password2 && (
                  <div className="d-block invalid-feedback">
                    {errors.password2}
                  </div>
                )}
              </div>
              <input type="submit" className="btn btn-info btn-block mt-4" />
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
export default Register2;
