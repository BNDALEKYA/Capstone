import React, { Fragment } from "react";
import spinner from "../../assests/img/spinner.gif";
function Spinner(props) {
  return (
    <Fragment>
      <img
        src={spinner}
        style={{ width: "200px", margin: "auto", display: "block" }}
        alt="Loading..."
      ></img>
    </Fragment>
  );
}

Spinner.propTypes = {};

export default Spinner;
