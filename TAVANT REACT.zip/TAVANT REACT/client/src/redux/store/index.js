import { applyMiddleware, createStore } from "redux";
//create store to create the redux store
//applymiddleware: to apply the thunk
import thunk from "redux-thunk";
//this is ur middleware will help u to connect to store to manipulate the contents
import { composeWithDevTools } from "redux-devtools-extension";
//will provide the access to ur redux devtools extn from chrome/firefox
import rootReducer from "../reducers";
import setAuthToken from "../../utls/setAuthToken";

const initialState = {};

const middleware = [thunk];

const store = createStore(
  rootReducer,
  initialState,
  composeWithDevTools(applyMiddleware(...middleware))
);

// set up a store subscription listener
// to store the users token in localStorage
//initialise current state from redux store for subscription comparison

//for preventing undefined error
let currentState = store.getState();
store.subscribe(() => {
  console.log("inside the subscribe from store index.js");
  let previousState = currentState;
  currentState = store.getState();

  if (previousState.auth.token !== currentState.auth.token) {
    const token = currentState.auth.token;
    setAuthToken(token);
  }
});
export default store;
