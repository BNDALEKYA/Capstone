const { default: api } = require("./api");

const setAuthToken = (token) => {
  if (token) {
    api.defaults.headers.common["x-auth-token"] = token;
    localStorage.setItem("token", token);
    //localStorage will store data inside the browser or application
    //LS-will be accessible to only to its domain contents

    //cookies vs localStorage
  } else {
    delete api.defaults.headers.common["x-auth-token"];
    localStorage.removeItem("token");
  }
};

export default setAuthToken;
