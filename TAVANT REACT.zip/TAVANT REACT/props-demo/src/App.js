import logo from "./logo.svg";
import "./App.css";
import ChildComponent from "./ChildComponent";

function App() {
  let dataFor3 = "srs";
  return (
    <div className="App">
      <ChildComponent
        name="lavu"
        name2="lavanya"
        dataFor3={dataFor3}
      ></ChildComponent>{" "}
    </div>
  );
}

export default App;
