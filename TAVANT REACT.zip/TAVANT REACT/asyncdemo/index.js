const fetch = require("node-fetch");

async function getData() {
  console.log("Starting");
  let response = await fetch("https://jsonplaceholder.typicode.com/todos/");
  console.log("after fetch ");
  let result = await response.json();
  console.log("after json()");
  console.log(result);
  console.log("end");
}

getData();
