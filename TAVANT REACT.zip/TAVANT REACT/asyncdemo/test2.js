const fetch = require("node-fetch");

const showRest = async () => {
  console.log("start");
  let response = await fetch("https://jsonplaceholder.typicode.com/todos/");

  console.log("after fetch method call");

  response.then((res) => {
    console.log(res.json());
  });
  let result = await response.json();
  console.log(result);
};

showRest();
